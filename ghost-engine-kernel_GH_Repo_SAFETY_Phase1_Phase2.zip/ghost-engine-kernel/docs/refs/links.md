# References (authoritative)

## CodeLaunch
- Rules (4 minutes / 8 slides; 30s silent demo video narrated live): https://codelaunch.com/startups/rules/
- Rules (alt): https://stage.codelaunch.com/rules/
- Application portal example (Pitch Deck + Mockups/Wireframes): https://codelaunch.com/apply/2026-test/

## AWS
- Well-Architected pillars: https://docs.aws.amazon.com/wellarchitected/latest/framework/definitions.html
