# 8‑Slide Deck Outline (CodeLaunch‑aligned)

Constraint source: https://codelaunch.com/startups/rules/

## Slide 1 — One‑liner
Ghost Engine is __________________________ for __________________________ who need __________________________.
Unlike __________________________, we deliver __________________________.

## Slide 2 — Pain (measurable)
- Time cost: ________
- $ cost: ________
- Risk: ________
- Proof: ________

## Slide 3 — Product (what it does)
- 1) ______  2) ______  3) ______

## Slide 4 — Golden path demo (what we prove)
- Step 1: ______
- Step 2: ______
- Step 3 (wow): ______
- Output: ______

## Slide 5 — Wedge + customer
- First buyer: ______
- First use case: ______
- Expansion: ______

## Slide 6 — Business model
- Subscription + usage + marketplace rev share

## Slide 7 — Defensibility
- Workflow lock‑in: ______
- Data flywheel: ______
- Ecosystem: ______

## Slide 8 — Ask + milestones
- Ask: ______
- 90 days: ______
- 12 months: ______
