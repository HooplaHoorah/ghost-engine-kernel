# Slide Copy Template

## Goal of this slide
- The single thought we want judges/audience to remember:

## On‑screen copy (minimal)
- Header:
- Subheader:
- 1–3 bullets:

## Spoken track (30–45 seconds)
- Sentence 1:
- Sentence 2:
- Sentence 3:
- Transition line:

## Evidence
- Metric, quote, or artifact:
