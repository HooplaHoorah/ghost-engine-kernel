# Pitch Compliance Checklist (CodeLaunch)

Source: https://codelaunch.com/startups/rules/

- [ ] Exactly 8 slides
- [ ] Rehearsed to 4 minutes
- [ ] Demo video: 30 seconds, silent, narrated live
- [ ] Demo does not rely on live randomness
- [ ] Claims are factual and defensible
