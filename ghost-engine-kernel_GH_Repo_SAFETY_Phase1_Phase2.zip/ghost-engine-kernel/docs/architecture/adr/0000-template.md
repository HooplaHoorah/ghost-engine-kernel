# ADR Template

## Title
## Status
Proposed | Accepted | Deprecated

## Context
## Decision
## Consequences
