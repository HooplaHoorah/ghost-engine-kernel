# UX Notes (judge-first)

- Every screen exists to support the demo.
- Provide a “Judge Mode” `/status` page: health, latency, last run, one-click demo.
- Prefer deterministic previews (seeded) over live generation on stage.
