# Defensibility / Moat

- Workflow lock‑in (packs/pipelines/versioning)
- Data flywheel (what variants succeed)
- Ecosystem plugins across engines
- Deterministic core; AI as optional layer
