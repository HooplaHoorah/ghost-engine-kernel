# Personas (first wedge)

1) Indie Dev — faster iteration, fewer art bottlenecks
2) Modder/Creator — publish packs, get paid, versioning
3) Studio Tools Lead — reproducible builds, compliance, reliability
