# Pricing (draft)

Indie: $99/mo + usage overage  
Creator: free to publish + rev share; Pro $19/mo  
Studio: seats + usage + SLA
