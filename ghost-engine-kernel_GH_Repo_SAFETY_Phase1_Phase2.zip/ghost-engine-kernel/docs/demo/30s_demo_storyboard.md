# 30‑Second Silent Demo Video Storyboard

Constraint source: https://codelaunch.com/startups/rules/

0–5s: Run Demo (deterministic runtime)
5–12s: Create Scene (ECS tick)
12–20s: AI Assist Variant (safe + cached)
20–27s: Build Replay (shareable output)
27–30s: Marketplace flash (publish → revenue share)
