# Judge Mode Spec

URL: `/status`

Must show:
- Health: orchestrator / worker / runtime / inference(optional)
- Last run + duration
- Latency p50/p95
- One-click “Run Golden Path”
- Logs tail
- “Use Cached Variant” toggle
