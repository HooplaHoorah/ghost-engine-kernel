# Live Demo Runbook

- Bad Wi‑Fi → CloudFront cached static + local backend
- Region issue → fail over / local + backup video
- “Is this real?” → show CI last green + metrics screenshot + run history
