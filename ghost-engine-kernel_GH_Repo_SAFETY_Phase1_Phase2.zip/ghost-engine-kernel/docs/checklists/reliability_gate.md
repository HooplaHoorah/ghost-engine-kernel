# Reliability Gate (stage-safe)

- [ ] No step depends on live AI to succeed
- [ ] Timeouts + graceful errors
- [ ] Local fallback runbook
