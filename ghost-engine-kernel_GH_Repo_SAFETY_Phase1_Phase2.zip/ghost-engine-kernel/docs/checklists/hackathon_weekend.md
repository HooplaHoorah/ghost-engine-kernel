# Hackathon Weekend Checklist

- [ ] Scope frozen (polish + reliability)
- [ ] Demo mode flags
- [ ] Backup video ready
- [ ] Narration rehearsed for silent demo video
