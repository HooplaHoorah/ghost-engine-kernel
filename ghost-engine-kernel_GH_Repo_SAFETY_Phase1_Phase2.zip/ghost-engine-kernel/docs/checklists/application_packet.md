# Application Packet Checklist

Typical requirement: Pitch Deck + Mockups/Wireframes.
Example portal: https://codelaunch.com/apply/2026-test/

- [ ] Deck exported to PDF
- [ ] Wireframes packaged
- [ ] One-liner finalized
- [ ] Team info verified
