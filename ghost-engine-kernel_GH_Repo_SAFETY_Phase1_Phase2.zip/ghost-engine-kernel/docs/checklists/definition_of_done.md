# Definition of Done (win conditions)

Demo:
- [ ] Golden path deterministic (works local + cloud)
- [ ] “Wow” step cache-first + fallback
- [ ] `/status` judge dashboard exists
- [ ] 30s silent demo video recorded

Feasibility:
- [ ] Health endpoints + smoke tests green
- [ ] CI green
- [ ] Observability screenshot ready

Business:
- [ ] Wedge + pricing + GTM written

Pitch packet:
- [ ] 8 slides, 4 minutes, compliant
- [ ] Wireframes ready to attach
