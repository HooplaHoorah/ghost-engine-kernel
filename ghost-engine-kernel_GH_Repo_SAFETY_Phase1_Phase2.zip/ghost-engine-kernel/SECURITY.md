# Security (template)

- No long-lived keys in git
- Prefer OIDC/federated identity for CI deploys
- Least-privilege IAM roles
- Use a secrets manager for secrets
