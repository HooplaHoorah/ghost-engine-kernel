# Contributing (template)

- Node 20+
- `docker compose -f 06_infra/local/docker-compose.yml up --build`
- PRs required to main
