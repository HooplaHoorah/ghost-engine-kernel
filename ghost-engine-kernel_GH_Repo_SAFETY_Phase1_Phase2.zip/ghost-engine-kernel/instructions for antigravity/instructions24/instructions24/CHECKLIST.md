# Checklist — Definition of Done (Slice 19 / instructions24)

## Markdown mode
- [ ] `--md` flag is parsed
- [ ] Report prints Markdown headings and bullet points
- [ ] Demo pack links appear as plain URLs
- [ ] Demo pack JSON appears in a ```json fenced block
- [ ] Default output unchanged when --md is not provided
- [ ] Exit codes unchanged

