# Checklist — Definition of Done (Slice 16 / instructions21)

## Open newest backup
- [ ] Button present in Backup Links panel
- [ ] Disabled/hidden when no backups exist
- [ ] Clicking loads a backup job via existing load flow (URL updates to ?jobId=)
- [ ] State updates after save/clear/generate

## Optional random backup
- [ ] Button present (optional)
- [ ] Picks a random item from demo pack
- [ ] Loads job correctly

