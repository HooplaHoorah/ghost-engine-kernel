# Pack summary improvements

## Status text
- While running:
  - “Generating 1/3… <label>”
- After completion:
  - “Saved 3/3 backups”
  - OR “Saved 2/3 backups — failed: <labels>”

## Optional list
Under status line, show a small list of failed labels for clarity.

