# Links

## Primary
- **Demo:** https://d3a3b2mntnsxvl.cloudfront.net/demo
- **Play Landing:** https://d3a3b2mntnsxvl.cloudfront.net/play
- **Health:** https://d3a3b2mntnsxvl.cloudfront.net/healthz

## Backup Jobs (Instant Play)
- **Backup 1:** `https://d3a3b2mntnsxvl.cloudfront.net/play?job=ed0f66d4-16cb-49ec-a05e-2d25e3d86a1f`
- **Backup 2:** `https://d3a3b2mntnsxvl.cloudfront.net/play?job=7a0a96c8-fa1d-46cf-a6ee-4498d4058d55`

## Backup Jobs (Demo Page)
- **Backup 1:** `https://d3a3b2mntnsxvl.cloudfront.net/demo?jobId=ed0f66d4-16cb-49ec-a05e-2d25e3d86a1f`
- **Backup 2:** `https://d3a3b2mntnsxvl.cloudfront.net/demo?jobId=7a0a96c8-fa1d-46cf-a6ee-4498d4058d55`
